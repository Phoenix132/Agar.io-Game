Please read the FAQ in advance.

YOU MUST SEARCH UP YOUR ERROR FIRST TO SEE IF IT IS REPRODUCED

What game mode were you in when you had the issue?

What version are you on?

What command did you type if any?

You must have a description as well

Most common questions involve:

Why is there an error "Cannot find module"
A: Do npm install after you cd into the repo.

VIOLATORS OF THIS WILL BE BANNED FOR 1 MONTH
