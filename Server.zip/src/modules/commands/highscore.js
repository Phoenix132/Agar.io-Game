module.exports = function (gameServer, split) {
  console.log("High score: " + gameServer.topscore + " By " + gameServer.topusername);
};
