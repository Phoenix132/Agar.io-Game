module.exports = function (gameServer, split) {
  gameServer.troll = [];
  console.log("[Console] Turned any Special Viruses (from op's) Into normal ones");

};
