'use strict';
module.exports = class LeaderBoard {
  constructor(gameServer) {
    this.gameServer = gameServer;
  }
  init() {}
  start() {}
  update(dt) {}
};
