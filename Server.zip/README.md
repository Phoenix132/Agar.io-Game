Not so really closed anymore
